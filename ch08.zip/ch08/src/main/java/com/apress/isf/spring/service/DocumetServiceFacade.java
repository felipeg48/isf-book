/**
 * 
 */
package com.apress.isf.spring.service;

import java.util.List;

import com.apress.isf.java.model.Document;
import com.apress.isf.java.model.Type;
import com.apress.isf.java.service.DocumentService;

/**
 * @author Felipe Gutierrez
 *
 */
public class DocumetServiceFacade implements DocumentService {

	
	public void createNewType(Type type) {
		
	}

	
	public void updateType(Type type) {
	
	}

	public void removeTypeById(String id) {
	
	}

	public List<Type> getAllDefinedTypes() {
		return null;
	}

	public Type getTypeById(String id) {
		return null;
	}

	public void createNewDocument(Document document) {
	
	}

	public void removeDocumentById(String id) {
	
	}

	public void updateDocument(Document document) {
	
	}

	public void updateLocationFromDocumentId(String documentId, String location) {
	
	}

}
