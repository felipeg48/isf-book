/**
 * 
 */
package com.apress.isf.java.service;

/**
 * @author Felipe Gutierrez
 *
 */
public interface Login {
	public boolean isAuthorized(String email, String pass);
}
